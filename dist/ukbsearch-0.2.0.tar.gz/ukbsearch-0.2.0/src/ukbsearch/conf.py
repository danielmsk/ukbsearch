

COLNAMES = ["Column", "UDI", "Count", "Type", "Description"]
COL_JUSTIFY = ["right", "left", "right", "center", "left"]